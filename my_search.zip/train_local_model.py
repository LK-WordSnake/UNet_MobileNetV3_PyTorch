import datetime
import torch
import os
import argparse
from config import cfg

from utils.logger import setup_logger
from datasets.make_dataset import make_dataloader
from create_model.make_local_model import make_local_model
from solver import make_optimizer
from solver.scheduler_factory import create_scheduler
from loss.make_loss import make_loss
from engine import do_train


def set_seed(seed):
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="ReID Baseline Training")
    parser.add_argument("--config_file",
                        default="", help="path to config file", type=str)

    parser.add_argument("opts", help="Modify config options using the command-line",
                        default=None, nargs=argparse.REMAINDER)

    parser.add_argument("--local_rank", default=-1, type=int)
    parser.add_argument("--dist", default=True, type=bool)
    args = parser.parse_args()

    args.local_rank = int(os.environ["LOCAL_RANK"])

    if args.config_file != "":
        cfg.merge_from_file(args.config_file)
        if len(cfg.BASE) > 0:
            cfg.merge_from_file(cfg.BASE)
        cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)

    output_dir = cfg.OUTPUT_DIR

    if output_dir and not os.path.exists(output_dir) and args.local_rank == 0:
        os.makedirs(output_dir)
    cfg.OUTPUT_DIR = output_dir
    cfg.freeze()

    set_seed(1234)

    if args.dist:
        torch.cuda.set_device(args.local_rank)

    logger = setup_logger("reid_baseline", output_dir, if_train=True)
    logger.info("Saving model in the path :{}".format(cfg.OUTPUT_DIR))

    if args.config_file != "":
        logger.info("Loaded configuration file {}".format(args.config_file))
        with open(args.config_file, 'r') as cf:
            config_str = "\n" + cf.read()

    if args.dist:
        torch.distributed.init_process_group(backend='nccl',
                                             init_method='env://',
                                             timeout=datetime.timedelta(1800))

    os.environ['CUDA_VISIBLE_DEVICES'] = cfg.MODEL.DEVICE_ID
    train_loader, val_loader, num_query, num_classes = make_dataloader(cfg)

    model = make_local_model(cfg, num_class=num_classes)

    loss_func = make_loss(cfg, num_classes=num_classes)

    optimizer = make_optimizer(cfg, model)

    scheduler = create_scheduler(cfg, optimizer)

    do_train(
        cfg,
        model,
        train_loader,
        val_loader,
        optimizer,
        scheduler,
        loss_func,
        num_query, args.local_rank
    )
