import torch

def make_loss(cfg, num_classes):
    xent = torch.nn.CrossEntropyLoss()
    print("label smooth off, numclasses:", num_classes)

    def loss_func(score, feat, target):
        ID_LOSS = xent(score, target)
        DUMMY_LOSS = torch.tensor([0.0], device=score.get_device())
        return [ID_LOSS, ID_LOSS, DUMMY_LOSS, 0.0]

    return loss_func


