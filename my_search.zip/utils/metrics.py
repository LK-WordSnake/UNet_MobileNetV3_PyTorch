import torch
import numpy as np
import os


def euclidean_distance(qf, gf):
    m = qf.shape[0]
    n = gf.shape[0]
    dist_mat = torch.pow(qf, 2).sum(dim=1, keepdim=True).expand(m, n) + \
               torch.pow(gf, 2).sum(dim=1, keepdim=True).expand(n, m).t()
    # dist_mat.addmm_(1, -2, qf, gf.t())
    dist_mat = dist_mat - 2 * torch.matmul(qf, gf.t())
    return dist_mat.cpu().numpy()

def cosine_similarity(qf, gf):
    epsilon = 0.00001
    dist_mat = qf.mm(gf.t())
    qf_norm = torch.norm(qf, p=2, dim=1, keepdim=True)  # mx1
    gf_norm = torch.norm(gf, p=2, dim=1, keepdim=True)  # nx1
    qg_normdot = qf_norm.mm(gf_norm.t())

    dist_mat = dist_mat.mul(1 / qg_normdot).cpu().numpy()
    dist_mat = np.clip(dist_mat, -1 + epsilon, 1 - epsilon)
    dist_mat = np.arccos(dist_mat)
    return dist_mat


def eval_func(distmat, q_pids, g_pids, q_camids, g_camids, max_rank=50):
    """Evaluation with market1501 metric
        Key: for each query identity, its gallery images from the same camera view are discarded.
        """
    num_q, num_g = distmat.shape
    # distmat g
    #    q    1 3 2 4
    #         4 1 2 3
    if num_g < max_rank:
        max_rank = num_g
        print("Note: number of gallery samples is quite small, got {}".format(num_g))
    indices = np.argsort(distmat, axis=1)
    #  0 2 1 3
    #  1 2 3 0
    matches = (g_pids[indices] == q_pids[:, np.newaxis]).astype(np.int32)
    # compute cmc curve for each query
    all_cmc = []
    all_AP = []
    num_valid_q = 0.  # number of valid query
    for q_idx in range(num_q):
        # get query pid and camid
        q_pid = q_pids[q_idx]
        q_camid = q_camids[q_idx]

        # remove gallery samples that have the same pid and camid with query
        order = indices[q_idx]  # select one row
        remove = (g_pids[order] == q_pid) & (g_camids[order] == q_camid)
        keep = np.invert(remove)

        # compute cmc curve
        # binary vector, positions with value 1 are correct matches
        orig_cmc = matches[q_idx][keep]
        if not np.any(orig_cmc):
            # this condition is true when query identity does not appear in gallery
            continue

        cmc = orig_cmc.cumsum()
        cmc[cmc > 1] = 1

        all_cmc.append(cmc[:max_rank])
        num_valid_q += 1.

        # compute average precision
        # reference: https://en.wikipedia.org/wiki/Evaluation_measures_(information_retrieval)#Average_precision
        num_rel = orig_cmc.sum()
        tmp_cmc = orig_cmc.cumsum()
        #tmp_cmc = [x / (i + 1.) for i, x in enumerate(tmp_cmc)]
        y = np.arange(1, tmp_cmc.shape[0] + 1) * 1.0
        tmp_cmc = tmp_cmc / y
        tmp_cmc = np.asarray(tmp_cmc) * orig_cmc
        AP = tmp_cmc.sum() / num_rel
        all_AP.append(AP)

    assert num_valid_q > 0, "Error: all query identities do not appear in gallery"

    all_cmc = np.asarray(all_cmc).astype(np.float32)
    all_cmc = all_cmc.sum(0) / num_valid_q
    mAP = np.mean(all_AP)

    return all_cmc, mAP


class R1_mAP_eval():
    def __init__(self, num_query, max_rank=50, feat_norm=True, reranking=False):
        super(R1_mAP_eval, self).__init__()
        self.num_query = num_query      # 4808
        self.max_rank = max_rank        # 50
        self.feat_norm = feat_norm      # True
        self.reranking = reranking      # False

    def reset(self):
        self.feats = []
        self.pids = []
        self.camids = []

    def update(self, output):  # called once for each batch
        feat, pid, camid = output
        self.feats.append(feat.cpu())
        self.pids.extend(np.asarray(pid))
        self.camids.extend(np.asarray(camid))

    def compute(self):
        feats = torch.cat(self.feats, dim=0)
        if self.feat_norm:
            print("The test feature is normalized")
            feats = torch.nn.functional.normalize(feats, dim=1, p=2)  # along channel
        # query
        qf = feats[:self.num_query]
        print('-/- ' * 100)
        print(qf)
        print('-/- ' * 100)
        q_pids = np.asarray(self.pids[:self.num_query])
        q_camids = np.asarray(self.camids[:self.num_query])
        # gallery
        gf = feats[self.num_query:]
        g_pids = np.asarray(self.pids[self.num_query:])

        g_camids = np.asarray(self.camids[self.num_query:])
        print('=> Computing DistMat with euclidean_distance')
        distmat = euclidean_distance(qf, gf)
        cmc, mAP = eval_func(distmat, q_pids, g_pids, q_camids, g_camids)

        return cmc, mAP, distmat, self.pids, self.camids, qf, gf


class CBIR_mAP_eval(R1_mAP_eval):

    def __init__(self, num_query, max_rank=50, feat_norm=True, reranking=False):
        R1_mAP_eval.__init__(self, num_query, max_rank=50, feat_norm=True, reranking=False)

    def compute(self):  # called after each epoch
        feats = torch.cat(self.feats, dim=0)
        if self.feat_norm:
            print("The test feature is normalized")
            feats = torch.nn.functional.normalize(feats, dim=1, p=2)  # along channel
        # query
        qf = feats[:self.num_query]
        q_pids = np.asarray(self.pids[:self.num_query])
        q_camids = np.asarray(self.camids[:self.num_query])
        # gallery
        gf = feats[self.num_query:]
        g_pids = np.asarray(self.pids[self.num_query:])

        g_camids = np.asarray(self.camids[self.num_query:])
        print('=> Computing DistMat with euclidean_distance')
        distmat = euclidean_distance(qf, gf)
        cmc, mAP = cbir_eval_func(distmat, q_pids, g_pids, q_camids, g_camids)

        return cmc, mAP, distmat, self.pids, self.camids, qf, gf


def cbir_eval_func(distmat, q_pids, g_pids, q_camids, g_camids, max_rank=10000):

    ids_map = 0.0
    querynum = 0
    distractor_flag = (g_pids == 9999) * (g_camids == 9999)
    all_tp_flag = []
    for i in range(0, q_pids.shape[0]):
        local_flag = g_camids == q_camids[i]
        local_flag = np.logical_or(local_flag, distractor_flag)
        local_index = np.where(local_flag == 1)[0]
        local_gal_pids = g_pids[local_index]
        local_gal_camids = g_camids[local_index]
        local_sims = distmat[i, local_index]
        idx = np.argsort(local_sims)

        valid1 = (np.where(local_gal_pids == q_pids[i]))[0]
        same_query_flag = local_gal_camids[valid1] == q_camids[i]
        valid2 = valid1[same_query_flag]
        valid = valid2

        # if len(valid) > 0:
        #     print('- ' * 200)
        querynum += 1

        # find all same ids with probability
        num_expected_positives = len(valid)
        if not num_expected_positives:
            continue
        recall_step = 1.0 / num_expected_positives
        count = 0
        id_map = 0.0
        gal_num = min(max_rank, len(idx))
        tp_flag = np.zeros((max_rank,), dtype=np.int)
        for j in range(0, gal_num):
            if idx[j] in valid:
                tp_flag[j] = 1
                if j == 0:
                    left_precision = 1.0
                else:
                    left_precision = count / j
                right_precision = (count + 1) / (j + 1)
                count += 1
                id_map += (left_precision + right_precision) * recall_step / 2
        ids_map += id_map
        tp_flag = tp_flag.cumsum()
        tp_flag[tp_flag > 1] = 1
        all_tp_flag.append(tp_flag[:max_rank])
    print(f'valid query num: {querynum}')
    ids_map = ids_map / querynum
    cmc = np.mean(all_tp_flag, axis=0)

    return cmc, ids_map
