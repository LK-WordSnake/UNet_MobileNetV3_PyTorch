import os
import numpy as np
import argparse

import cv2
import torch
import torch.nn as nn
from torch.cuda import amp
from PIL import Image
from tqdm import tqdm

from models.local_feat import make_local_model

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ['CUDA_VISIBLE_DEVICES'] = "0"

def create_model(backbone):
    model_backbone = {'R50': 'resnet50',
                      'RXt101ibn': 'resnext101_ibn_a',
                      'ResNeSt101': 'resnest101'}

    model = make_local_model(model_backbone[backbone])
    model_name = opt.weights
    model_path = os.path.join(opt.model_path, model_name)
    model.load_param(model_path)
    model = nn.DataParallel(model)
    model.to('cuda')
    model.eval()
    return model


def load_image(img_path):
    mean = torch.tensor([123.675, 116.280, 103.530]).to('cuda')
    std = torch.tensor([57.0, 57.0, 57.0]).to('cuda')

    img = cv2.imread(img_path)
    img = cv2.resize(img, (opt.img_size, opt.img_size))
    img = torch.tensor(img)
    img = img[:, :, [2, 1, 0]]
    img = torch.unsqueeze(img, dim=0).to('cuda')
    img = (img - mean) / std
    img = img.permute(0, 3, 1, 2)
    img = img.float()
    return img


def main():
    # 读取特征
    info = torch.load(os.path.join('outputs', '{}_features_{}_local.pt'.format(opt.backbone, str(opt.data_code))), map_location='cuda')
    features = info['features']
    # {image_path: feature, image_path: feature, image_path: feature ......}

    # 提取特征
    model = create_model(opt.backbone)

    os.makedirs(os.path.join(opt.out_dir, opt.backbone), exist_ok=True)
    # 遍历数据
    for i in tqdm(os.listdir(opt.query_root)):
        code = i.split('.')[0]
        img_path = os.path.join(opt.query_root, code + '.jpg')
        # 加载数据
        img = load_image(img_path)

        # 提取特征
        with amp.autocast():
            feat = model(img)

        feat = feat / torch.norm(feat, 2, 1, keepdim=True)
        feat = feat.cpu().detach().numpy()
        # 完成特征提取

        count = 0
        result_sort = {}
        os.makedirs(os.path.join(opt.out_dir, opt.backbone, code), exist_ok=True)

        # 计算相似度，保存为字典： {'image_path': 'score'}
        for p, f in features.items():
            score = np.dot(feat, f.T)[0] * 100
            result_sort[p] = score

        # 字典排序
        result_sort = sorted(result_sort.items(), key=lambda x: x[1], reverse=True)

        top_k = opt.top_k
        # 截取指定的 topk 结果
        for i, (k, v) in enumerate(dict(result_sort[: top_k]).items()):

            count += 1
            # 先读取再保存
            org_img = Image.open(img_path)
            res_img = Image.open(k)
            res_img_name = k.split('/')[-1].split('.')[0]

            # 数据保存规则
            org_img.save(os.path.join(opt.out_dir, opt.backbone, code, 'query.jpg'))
            # # res_img.save(os.path.join('result', code, res_img_name + '_top{}.jpg'.format(str(i + 1))))
            res_img.save(os.path.join(opt.out_dir, opt.backbone, code, 'top{}.jpg'.format(str(i + 1))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # 超参数
    # 模型文件名称
    parser.add_argument('--weights', type=str, default='resnest101_2839.pth')

    # 主干网络
    parser.add_argument('--backbone', type=str, default='ResNeSt101',
                        help='R50'                  # 256
                             'RXt101ibn'            # 384
                             'ResNeSt101')

    # 输入尺寸
    parser.add_argument('--img_size', type=int, default=384,
                        help='256, 384, 448, 512')

    # 模型路径
    parser.add_argument('--model_path', type=str, default='./weights/')

    # 选择保留多少张图像
    parser.add_argument('--top_k', type=int, default=30)

    # 数据标号
    parser.add_argument('--data_code', type=str, default='278')

    # query 数据路径（待查询数据路径）
    parser.add_argument('--query_root', type=str, default='inference_278')

    # 数据保存路径
    parser.add_argument('--out_dir', type=str, default='result')

    opt = parser.parse_args()

    main()

