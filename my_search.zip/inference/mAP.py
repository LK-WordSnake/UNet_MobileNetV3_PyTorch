import os
import sys
import numpy as np
import argparse
import time

import cv2
import torch
import torch.nn as nn
from torch.cuda import amp
from tqdm import tqdm

from models.make_model import make_model
from models.local_feat import make_local_model
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ['CUDA_VISIBLE_DEVICES'] = "4"

def create_model(backbone):
    model_backbone = {'R50': 'resnet50',
                      'RXt101ibn': 'resnext101_ibn_a',
                      'ResNeSt101': 'resnest101'}

    # model = make_model(model_backbone[backbone])
    model = make_local_model(model_backbone[backbone])
    model_name = opt.weights
    model_path = os.path.join(opt.model_path, model_name)
    model.load_param(model_path)
    model = nn.DataParallel(model)
    model.to('cuda')
    model.eval()
    return model


def load_image(img_path):
    mean = torch.tensor([123.675, 116.280, 103.530]).to('cuda')
    std = torch.tensor([57.0, 57.0, 57.0]).to('cuda')

    img = cv2.imread(img_path)
    img = cv2.resize(img, (opt.img_size, opt.img_size))
    img = torch.tensor(img)
    img = img[:, :, [2, 1, 0]]
    img = torch.unsqueeze(img, dim=0).to('cuda')
    img = (img - mean) / std
    img = img.permute(0, 3, 1, 2)
    img = img.float()
    return img


def main():
    # 读取特征
    # info = torch.load(os.path.join('outputs', '{}_features_{}.pt'.format(opt.backbone, opt.data_code)), map_location='cuda')
    info = torch.load(os.path.join('outputs', '{}_features_{}_local.pt'.format(opt.backbone, opt.data_code)), map_location='cuda')
    features = info['features']
    # {image_path: feature, image_path: feature, image_path: feature ......}

    # 提取特征
    model = create_model(opt.backbone)

    mAP_info = []
    top_k = opt.top_k
    all_time = []
    for i in tqdm(os.listdir(opt.root)):
        code = i.split('_')[0]
        img_path = os.path.join(opt.root, i)
        start_time = time.time()
        img = load_image(img_path)

        with amp.autocast():
            feat = model(img)

        feat = feat / torch.norm(feat, 2, 1, keepdim=True)
        feat = feat.cpu().detach().numpy()
        end_time = time.time()
        result_sort = {}

        for p, f in features.items():
            score = np.dot(feat, f.T)[0] * 100
            result_sort[p] = score

        result_sort = sorted(result_sort.items(), key=lambda x: x[1], reverse=True)

        mAP_info_single = []
        count_all = 0
        count_query = 0

        # start_time = time.time()
        for i, (k, v) in enumerate(dict(result_sort[: top_k]).items()):
            count_all += 1
            res_img_code = k.split('/')[-1].split('_')[0]

            if res_img_code == code:
                count_query += 1
                mAP_info_single.append(count_query / count_all)

        # end_time = time.time()
        times = end_time - start_time
        all_time.append(times)

        try:
            mAP_info.append(sum(mAP_info_single) / count_query)
        except:
            mAP_info.append(sum(mAP_info_single) / 1)

    mAP = sum(mAP_info) / len(os.listdir(opt.root))
    timer = sum(all_time) / len(os.listdir(opt.root))
    print('mAP@{}: {}'.format(top_k, mAP))
    print(f'Average single img search time: {timer:.8f}s')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # 超参数
    parser.add_argument('--weights', type=str, default='resnest101_2839.pth',
                        help='resnext101_ibn_a_100.pth')

    parser.add_argument('--backbone', type=str, default='ResNeSt101',
                        help='R50'                  # 256
                             'RXt101ibn'            # 384
                             'ResNeSt101')           # 384

    parser.add_argument('--model_path', type=str, default='../input/models/')

    parser.add_argument('--img_size', type=int, default=384,
                        help='256, 384, 448, 512')

    parser.add_argument('--data_code', type=str, default='84')
    parser.add_argument('--top_k', type=int, default=29)
    parser.add_argument('--root', type=str, default='inference/Oxd5k')
    opt = parser.parse_args()

    main()
